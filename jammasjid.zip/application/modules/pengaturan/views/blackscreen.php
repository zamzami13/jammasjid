<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body {
			background-color: #000;
		}
	</style>
</head>
<body>

</body>
</html>