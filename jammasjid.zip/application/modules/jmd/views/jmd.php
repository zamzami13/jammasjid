<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width" />
    <meta charSet="utf-8" />
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
    <title>digitalbee.id - Jam masjid digital</title>
    <meta name="description" content="Produk asli jam masjid digital belinya Lewat https://digitalbee.id/jam-masjid-digital." />
    <link rel="canonical" href="" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Jam masjid digital" />
    <meta property="og:description" content="Produk asli jam masjid digital belinya Lewat https://digitalbee.id/jam-masjid-digital" />
    <meta property="og:url" content="" />
    <meta property="og:site_name" content="Jam masjid digital" />
    <meta property="article:author" content="https://web.facebook.com/profile.php?id=100001111528614" />
    <meta property="article:published_time" content="2021-08-28" />
    <meta property="article:modified_time" content="2021-08-28" />
    <meta property="og:image" content="https://digitalbee.id/blogapi/public/images/photo-1513542789411-b6a5d4f31634.jpeg" />
    <meta property="og:image:width" content="500" />
    <meta property="og:image:height" content="500" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:label1" content="Written by" />
    <meta name="twitter:data1" content="Erik Sanjaya" />
    <meta name="twitter:label2" content="Est. reading time" />
    <meta name="twitter:data2" content="3 minute" />
</head>

<body>
    <?php echo $_sub_page_title; ?>
</body>

</html>