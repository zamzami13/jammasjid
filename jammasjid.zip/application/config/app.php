<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['secrete_key'] 			= '249b0c863c285de812e5d25a159c2141';
$config['encryption_iv'] 		= '249b0c863c285de812e5d25a159c2141';
$config['encryption_method'] 	= 'aes-256-cbc';